package com.mysite.taskapp.interfaces;

import com.mysite.taskapp.model.TasksModel;

public interface TaskInterface {
    void onItemClicked(TasksModel tasksModel);
}

